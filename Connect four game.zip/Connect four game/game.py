import math
import random
import sys
import pygame
from config import (screen, WIDTH, HEIGHT, COLS, ROWS, SQUARESIZE,
                    RED, YELLOW)
from board import (create_board, drop_piece_in_col, is_valid_location,
                   get_valid_locations, winning_move, is_board_full)
from ai import minimax
from sounds import play_sound
from effects import Particle, Star
from renderer import (draw_gradient_bg, draw_board_glow, draw_header,
                      draw_hover, draw_footer, draw_menu, draw_game_over)


def main():
    stars = [Star() for _ in range(80)]
    particles = []

    selected_mode = 2
    selected_diff = 2
    game_state = "menu"
    board = create_board()
    game_over = False
    turn = random.randint(0, 1)
    scores = [0, 0]
    hover_col = COLS // 2
    winning_cells = None

    clock = pygame.time.Clock()

    while True:
        dt = clock.tick(60)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    if game_state == "game":
                        game_state = "menu"
                    else:
                        pygame.quit()
                        sys.exit()

                if game_state == "menu":
                    if event.key == pygame.K_1 or event.key == pygame.K_KP1:
                        selected_mode = 1
                    elif event.key == pygame.K_2 or event.key == pygame.K_KP2:
                        selected_mode = 2
                    elif event.key == pygame.K_3 or event.key == pygame.K_KP3:
                        selected_diff = 3
                    elif event.key == pygame.K_UP:
                        if selected_mode > 1:
                            selected_mode -= 1
                    elif event.key == pygame.K_DOWN:
                        if selected_mode < 2:
                            selected_mode += 1
                    elif event.key == pygame.K_LEFT:
                        if selected_diff > 1:
                            selected_diff -= 1
                    elif event.key == pygame.K_RIGHT:
                        if selected_diff < 3:
                            selected_diff += 1
                    elif event.key == pygame.K_RETURN or event.key == pygame.K_SPACE:
                        play_sound('click')
                        game_state = "game"
                        board = create_board()
                        game_over = False
                        turn = random.randint(0, 1)
                        winning_cells = None

                elif game_state == "game":
                    if event.key == pygame.K_r:
                        board = create_board()
                        game_over = False
                        turn = random.randint(0, 1)
                        winning_cells = None
                    elif event.key == pygame.K_m:
                        game_state = "menu"
                    elif not game_over:
                        if event.key == pygame.K_LEFT:
                            hover_col = max(0, hover_col - 1)
                        elif event.key == pygame.K_RIGHT:
                            hover_col = min(COLS - 1, hover_col + 1)
                        elif event.key == pygame.K_d:
                            valid = get_valid_locations(board)
                            if hover_col in valid and not (selected_mode == 2 and turn == 1):
                                drop_piece_in_col(board, hover_col, turn + 1)
                                result = winning_move(board, turn + 1)
                                if result:
                                    winning_cells = result
                                    game_over = True
                                    scores[turn] += 1
                                    play_sound('win')
                                    for _ in range(60):
                                        px = random.randint(0, WIDTH)
                                        py = random.randint(HEIGHT // 3, HEIGHT // 2)
                                        c = RED if turn == 1 else YELLOW
                                        particles.append(Particle(px, py, c))
                                elif is_board_full(board):
                                    game_over = True
                                    play_sound('draw')
                                else:
                                    turn = (turn + 1) % 2
                                    if selected_mode == 2 and turn == 1 and not game_over:
                                        ai_depth = selected_diff + 1
                                        col, score = minimax(board, ai_depth, -math.inf, math.inf, True, 1)
                                        if col is not None and is_valid_location(board, col):
                                            drop_piece_in_col(board, col, 1)
                                            result2 = winning_move(board, 1)
                                            if result2:
                                                winning_cells = result2
                                                game_over = True
                                                scores[1] += 1
                                                play_sound('win')
                                                for _ in range(60):
                                                    px = random.randint(0, WIDTH)
                                                    py = random.randint(HEIGHT // 3, HEIGHT // 2)
                                                    particles.append(Particle(px, py, YELLOW))
                                            elif is_board_full(board):
                                                game_over = True
                                                play_sound('draw')
                                            else:
                                                turn = 0

            if game_state == "menu":
                if event.type == pygame.MOUSEBUTTONDOWN:
                    mx, my = event.pos
                    box_w = 420
                    box_x = WIDTH // 2 - box_w // 2
                    box_y = 180

                    for i in range(2):
                        y = box_y + 75 + i * 65
                        btn = pygame.Rect(box_x + 30, y, box_w - 60, 50)
                        if btn.collidepoint(mx, my):
                            selected_mode = i + 1
                            play_sound('click')

                    diff_y = box_y + 300 + 20
                    for i in range(3):
                        y = diff_y + 55 + i * 28
                        hit_area = pygame.Rect(box_x + 30, y - 5, box_w - 60, 25)
                        if hit_area.collidepoint(mx, my):
                            selected_diff = i + 1
                            play_sound('click')

                    start_y = diff_y + 165
                    start_btn = pygame.Rect(box_x + 60, start_y, box_w - 120, 45)
                    if start_btn.collidepoint(mx, my):
                        play_sound('click')
                        game_state = "game"
                        board = create_board()
                        game_over = False
                        turn = random.randint(0, 1)
                        winning_cells = None

            if game_state == "game" and not game_over:
                if event.type == pygame.MOUSEMOTION:
                    posx = event.pos[0]
                    hover_col = int(posx // SQUARESIZE)
                    hover_col = max(0, min(hover_col, COLS - 1))

                if event.type == pygame.MOUSEBUTTONDOWN:
                    posx = event.pos[0]
                    col = int(posx // SQUARESIZE)
                    valid = get_valid_locations(board)

                    if col in valid and not (selected_mode == 2 and turn == 1):
                        drop_piece_in_col(board, col, turn + 1)
                        result = winning_move(board, turn + 1)
                        if result:
                            winning_cells = result
                            game_over = True
                            scores[turn] += 1
                            play_sound('win')
                            for _ in range(60):
                                px = random.randint(0, WIDTH)
                                py = random.randint(HEIGHT // 3, HEIGHT // 2)
                                c = RED if turn == 1 else YELLOW
                                particles.append(Particle(px, py, c))
                        elif is_board_full(board):
                            game_over = True
                            play_sound('draw')
                        else:
                            turn = (turn + 1) % 2
                            if selected_mode == 2 and turn == 1 and not game_over:
                                ai_depth = selected_diff + 1
                                col, score = minimax(board, ai_depth, -math.inf, math.inf, True, 1)
                                if col is not None and is_valid_location(board, col):
                                    drop_piece_in_col(board, col, 1)
                                    result2 = winning_move(board, 1)
                                    if result2:
                                        winning_cells = result2
                                        game_over = True
                                        scores[1] += 1
                                        play_sound('win')
                                        for _ in range(60):
                                            px = random.randint(0, WIDTH)
                                            py = random.randint(HEIGHT // 3, HEIGHT // 2)
                                            particles.append(Particle(px, py, YELLOW))
                                    elif is_board_full(board):
                                        game_over = True
                                        play_sound('draw')
                                    else:
                                        turn = 0

        if game_state == "menu":
            draw_menu(stars, selected_mode, selected_diff)
            pygame.display.update()
            continue

        draw_gradient_bg(screen)
        time_val = pygame.time.get_ticks() * 0.001
        for star in stars:
            star.draw(screen, time_val)

        valid = get_valid_locations(board)
        draw_header(turn, selected_mode, scores, selected_diff)
        draw_board_glow(board, winning_cells)

        if not game_over:
            draw_hover(hover_col, turn + 1, valid)

        draw_footer()

        for p in particles[:]:
            p.update()
            p.draw(screen)
            if p.life <= 0:
                particles.remove(p)

        if game_over:
            draw_game_over(turn + 1 if winning_move(board, turn + 1) else 0,
                           selected_mode, particles)

        pygame.display.update()
