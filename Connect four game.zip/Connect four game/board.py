from config import COLS, ROWS
from sounds import play_sound


def create_board():
    return [[0] * COLS for _ in range(ROWS)]


def drop_piece(board, row, col, piece):
    board[row][col] = piece


def is_valid_location(board, col):
    return board[0][col] == 0


def get_next_open_row(board, col):
    for r in range(ROWS - 1, -1, -1):
        if board[r][col] == 0:
            return r
    return -1


def get_valid_locations(board):
    return [c for c in range(COLS) if is_valid_location(board, c)]


def drop_piece_in_col(board, col, piece):
    valid = get_valid_locations(board)
    if col not in valid:
        return False
    row = get_next_open_row(board, col)
    drop_piece(board, row, col, piece)
    play_sound('drop')
    return True


def winning_move(board, piece):
    for c in range(COLS - 3):
        for r in range(ROWS):
            if all(board[r][c + i] == piece for i in range(4)):
                return [(r, c + i) for i in range(4)]

    for c in range(COLS):
        for r in range(ROWS - 3):
            if all(board[r + i][c] == piece for i in range(4)):
                return [(r + i, c) for i in range(4)]

    for c in range(COLS - 3):
        for r in range(3, ROWS):
            if all(board[r - i][c + i] == piece for i in range(4)):
                return [(r - i, c + i) for i in range(4)]

    for c in range(COLS - 3):
        for r in range(ROWS - 3):
            if all(board[r + i][c + i] == piece for i in range(4)):
                return [(r + i, c + i) for i in range(4)]

    return None


def is_board_full(board):
    return all(board[0][c] != 0 for c in range(COLS))


def is_terminal_node(board):
    return winning_move(board, 1) is not None or \
           winning_move(board, 2) is not None or \
           is_board_full(board)
