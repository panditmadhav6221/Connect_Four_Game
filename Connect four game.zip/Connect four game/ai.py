import math
import random
from config import COLS, ROWS
from board import (get_valid_locations, is_valid_location,
                   get_next_open_row, drop_piece, winning_move,
                   is_board_full, is_terminal_node)


def evaluate_window(window, piece):
    score = 0
    opp = 1 if piece == 2 else 2

    if window.count(piece) == 4:
        score += 100
    elif window.count(piece) == 3 and window.count(0) == 1:
        score += 10
    elif window.count(piece) == 2 and window.count(0) == 2:
        score += 4

    if window.count(opp) == 3 and window.count(0) == 1:
        score -= 8

    return score


def score_position(board, piece):
    score = 0
    center = [board[r][COLS // 2] for r in range(ROWS)]
    score += center.count(piece) * 6

    for r in range(ROWS):
        row = board[r]
        for c in range(COLS - 3):
            score += evaluate_window(row[c:c + 4], piece)

    for c in range(COLS):
        col = [board[r][c] for r in range(ROWS)]
        for r in range(ROWS - 3):
            score += evaluate_window(col[r:r + 4], piece)

    for r in range(ROWS - 3):
        for c in range(COLS - 3):
            score += evaluate_window(
                [board[r + i][c + i] for i in range(4)], piece)

    for r in range(3, ROWS):
        for c in range(COLS - 3):
            score += evaluate_window(
                [board[r - i][c + i] for i in range(4)], piece)

    return score


def minimax(board, depth, alpha, beta, maximizing, piece):
    valid = get_valid_locations(board)
    is_terminal = is_terminal_node(board)
    opp = 1 if piece == 2 else 2

    if depth == 0 or is_terminal:
        if is_terminal:
            if winning_move(board, piece):
                return None, 999999
            elif winning_move(board, opp):
                return None, -999999
            else:
                return None, 0
        return None, score_position(board, piece)

    if maximizing:
        value = -math.inf
        best_col = random.choice(valid)
        for col in valid:
            row = get_next_open_row(board, col)
            b_copy = [r[:] for r in board]
            drop_piece(b_copy, row, col, piece)
            _, new_score = minimax(b_copy, depth - 1, alpha, beta, False, piece)
            if new_score > value:
                value = new_score
                best_col = col
            alpha = max(alpha, value)
            if alpha >= beta:
                break
        return best_col, value
    else:
        value = math.inf
        best_col = random.choice(valid)
        for col in valid:
            row = get_next_open_row(board, col)
            b_copy = [r[:] for r in board]
            drop_piece(b_copy, row, col, opp)
            _, new_score = minimax(b_copy, depth - 1, alpha, beta, True, piece)
            if new_score < value:
                value = new_score
                best_col = col
            beta = min(beta, value)
            if alpha >= beta:
                break
        return best_col, value
