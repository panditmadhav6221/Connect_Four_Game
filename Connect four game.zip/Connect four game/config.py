import os
import pygame

os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = '1'

try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False

pygame.init()
pygame.mixer.init(frequency=44100, size=-16, channels=1, buffer=512)

SQUARESIZE = 100
COLS = 7
ROWS = 6
WIDTH = COLS * SQUARESIZE
HEIGHT = (ROWS + 1) * SQUARESIZE + 60
SIZE = (WIDTH, HEIGHT)
RADIUS = SQUARESIZE // 2 - 6

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (220, 30, 30)
RED_LIGHT = (255, 80, 80)
RED_DARK = (160, 20, 20)
YELLOW = (240, 210, 30)
YELLOW_LIGHT = (255, 255, 120)
YELLOW_DARK = (180, 160, 20)
BOARD_COLOR = (25, 60, 160)
BOARD_DARK = (15, 40, 120)
BOARD_HIGHLIGHT = (40, 90, 220)
BG_TOP = (10, 10, 40)
BG_BOTTOM = (20, 20, 80)
GREEN = (30, 180, 60)
GREY = (128, 128, 128)
GOLD = (255, 215, 0)
SILVER = (192, 192, 192)

screen = pygame.display.set_mode(SIZE)
pygame.display.set_caption("Connect Four")

TITLE_FONT = pygame.font.SysFont("segoeui", 52, bold=True)
MENU_FONT = pygame.font.SysFont("segoeui", 40, bold=True)
SCORE_FONT = pygame.font.SysFont("segoeui", 28, bold=True)
INFO_FONT = pygame.font.SysFont("segoeui", 22)
SMALL_FONT = pygame.font.SysFont("segoeui", 18)
WIN_FONT = pygame.font.SysFont("segoeui", 56, bold=True)
TURN_FONT = pygame.font.SysFont("segoeui", 20, bold=True)
