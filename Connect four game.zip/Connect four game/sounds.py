import pygame
from config import HAS_NUMPY


def generate_sounds():
    sounds = {}
    try:
        sample_rate = 44100

        def make_beep(freq, duration, volume=0.3, fade=True):
            if not HAS_NUMPY:
                return None
            import numpy as np
            t = np.linspace(0, duration, int(sample_rate * duration), False)
            wave = volume * np.sin(2 * np.pi * freq * t)
            if fade:
                fade_len = min(len(wave) // 4, 1000)
                fade_in = np.linspace(0, 1, fade_len)
                fade_out = np.linspace(1, 0, fade_len)
                wave[:fade_len] *= fade_in
                wave[-fade_len:] *= fade_out
            wave = (wave * 32767).astype(np.int16)
            return pygame.mixer.Sound(buffer=wave.tobytes())

        sounds['drop'] = make_beep(300, 0.1, 0.25)
        sounds['win'] = make_beep(880, 0.5, 0.3, fade=False)
        sounds['draw'] = make_beep(220, 0.4, 0.2)
        sounds['click'] = make_beep(660, 0.05, 0.15)
    except Exception:
        pass
    return sounds


SOUNDS = generate_sounds()


def play_sound(name):
    if name in SOUNDS and SOUNDS[name]:
        try:
            SOUNDS[name].play()
        except Exception:
            pass
