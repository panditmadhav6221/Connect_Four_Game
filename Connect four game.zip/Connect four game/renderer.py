import math
import random
import pygame
from config import (screen, WIDTH, HEIGHT, COLS, ROWS, SQUARESIZE, RADIUS,
                    WHITE, BLACK, RED, RED_LIGHT, RED_DARK,
                    YELLOW, YELLOW_LIGHT, YELLOW_DARK,
                    BOARD_COLOR, BOARD_DARK, BOARD_HIGHLIGHT,
                    BG_TOP, BG_BOTTOM, GREEN, GREY, GOLD, SILVER,
                    TITLE_FONT, MENU_FONT, SCORE_FONT, INFO_FONT,
                    SMALL_FONT, WIN_FONT, TURN_FONT)
from board import winning_move
from effects import Particle


def draw_gradient_bg(surface):
    for y in range(HEIGHT):
        ratio = y / HEIGHT
        r = int(BG_TOP[0] + (BG_BOTTOM[0] - BG_TOP[0]) * ratio)
        g = int(BG_TOP[1] + (BG_BOTTOM[1] - BG_TOP[1]) * ratio)
        b = int(BG_TOP[2] + (BG_BOTTOM[2] - BG_TOP[2]) * ratio)
        pygame.draw.line(surface, (r, g, b), (0, y), (WIDTH, y))


def draw_board_glow(board, winning_cells=None):
    for c in range(COLS):
        for r in range(ROWS):
            x = c * SQUARESIZE
            y = (r + 1) * SQUARESIZE
            cell_rect = pygame.Rect(x + 2, y + 2, SQUARESIZE - 4, SQUARESIZE - 4)

            is_winning = winning_cells and (r, c) in winning_cells

            if is_winning:
                glow_surf = pygame.Surface((SQUARESIZE, SQUARESIZE), pygame.SRCALPHA)
                pulse = abs(math.sin(pygame.time.get_ticks() * 0.005)) * 100 + 50
                color = RED_LIGHT if board[r][c] == 1 else YELLOW_LIGHT
                pygame.draw.rect(glow_surf, (*color, int(pulse)),
                                 (0, 0, SQUARESIZE, SQUARESIZE), border_radius=8)
                screen.blit(glow_surf, (x, y))

            pygame.draw.rect(screen, BOARD_COLOR, cell_rect, border_radius=6)

            if board[r][c] == 0:
                pygame.draw.rect(screen, BOARD_DARK, cell_rect, border_radius=6)

            if board[r][c] == 1:
                center = (x + SQUARESIZE // 2, y + SQUARESIZE // 2)
                pygame.draw.circle(screen, RED_DARK, center, RADIUS)
                pygame.draw.circle(screen, RED, center, RADIUS - 2)
                highlight = (center[0] - 12, center[1] - 12)
                pygame.draw.circle(screen, RED_LIGHT, highlight, RADIUS // 3)

            elif board[r][c] == 2:
                center = (x + SQUARESIZE // 2, y + SQUARESIZE // 2)
                pygame.draw.circle(screen, YELLOW_DARK, center, RADIUS)
                pygame.draw.circle(screen, YELLOW, center, RADIUS - 2)
                highlight = (center[0] - 12, center[1] - 12)
                pygame.draw.circle(screen, YELLOW_LIGHT, highlight, RADIUS // 3)


def draw_header(turn, mode, scores, ai_depth):
    header_h = 60
    pygame.draw.rect(screen, (15, 15, 50), (0, 0, WIDTH, header_h))
    pygame.draw.line(screen, BOARD_HIGHLIGHT, (0, header_h - 1), (WIDTH, header_h - 1), 2)

    turn_color = RED if turn == 1 else YELLOW
    turn_name = "RED" if turn == 1 else "YELLOW"
    if mode == 2 and turn == 2:
        turn_name = "AI"

    indicator = pygame.Surface((20, 20), pygame.SRCALPHA)
    pygame.draw.circle(indicator, turn_color, (10, 10), 8)
    screen.blit(indicator, (20, 20))

    turn_text = TURN_FONT.render(f"  {turn_name}'s Turn", True, turn_color)
    screen.blit(turn_text, (40, 18))

    title = TITLE_FONT.render("CONNECT 4", True, GOLD)
    screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 8))

    p1_color = RED_LIGHT if scores[0] > scores[1] else RED
    p2_color = YELLOW_LIGHT if scores[1] > scores[0] else YELLOW
    p1_label = "YOU" if mode == 2 else "RED"
    p2_label = "AI" if mode == 2 else "YELLOW"

    p1_text = SCORE_FONT.render(f"{p1_label}: {scores[0]}", True, p1_color)
    p2_text = SCORE_FONT.render(f"{p2_label}: {scores[1]}", True, p2_color)
    screen.blit(p1_text, (WIDTH - 200, 10))
    screen.blit(p2_text, (WIDTH - 200, 36))

    if mode == 2:
        diff_names = {1: "Easy", 2: "Medium", 3: "Hard"}
        diff = diff_names.get(ai_depth, "Hard")
        diff_text = SMALL_FONT.render(f"AI: {diff}", True, GREY)
        screen.blit(diff_text, (WIDTH - 95, 40))


def draw_hover(col, piece, valid_locations):
    if col not in valid_locations:
        return
    color = RED if piece == 1 else YELLOW
    light = RED_LIGHT if piece == 1 else YELLOW_LIGHT
    x = col * SQUARESIZE + SQUARESIZE // 2
    y = 60 + SQUARESIZE // 2

    bob = math.sin(pygame.time.get_ticks() * 0.005) * 4

    pygame.draw.circle(screen, color, (x, int(y + bob)), RADIUS - 3)
    pygame.draw.circle(screen, light, (x - 8, int(y + bob - 8)), RADIUS // 4)

    arrow_points = [
        (x, int(y + bob + RADIUS + 5)),
        (x - 8, int(y + bob + RADIUS - 5)),
        (x + 8, int(y + bob + RADIUS - 5)),
    ]
    pygame.draw.polygon(screen, color, arrow_points)


def draw_footer():
    footer_y = HEIGHT - 55
    pygame.draw.rect(screen, (15, 15, 50), (0, footer_y, WIDTH, 55))
    pygame.draw.line(screen, BOARD_HIGHLIGHT, (0, footer_y), (WIDTH, footer_y), 1)

    hints = [
        "LEFT/RIGHT: Select Col",
        "D: Drop Piece",
        "R: Restart",
        "M: Menu",
    ]
    hint_text = "  |  ".join(hints)
    text = SMALL_FONT.render(hint_text, True, GREY)
    screen.blit(text, (WIDTH // 2 - text.get_width() // 2, footer_y + 18))


def draw_menu(stars, selected_mode, selected_diff):
    draw_gradient_bg(screen)

    time_val = pygame.time.get_ticks() * 0.001
    for star in stars:
        star.draw(screen, time_val)

    title = TITLE_FONT.render("CONNECT FOUR", True, GOLD)
    glow = TITLE_FONT.render("CONNECT FOUR", True, (255, 255, 200))
    screen.blit(glow, (WIDTH // 2 - title.get_width() // 2 + 2, 72))
    screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 70))

    credit = SMALL_FONT.render("Built with Python & Pygame  |  @InternPe", True, GREY)
    screen.blit(credit, (WIDTH // 2 - credit.get_width() // 2, 135))

    modes = [
        ("1", "Player vs Player", "Play with a friend locally"),
        ("2", "Player vs AI", "Challenge the computer"),
    ]
    diffs = [
        ("1", "Easy", "Random moves"),
        ("2", "Medium", "Smart AI"),
        ("3", "Hard", "Unbeatable AI"),
    ]

    box_w = 420
    box_h = 300
    box_x = WIDTH // 2 - box_w // 2
    box_y = 180
    box = pygame.Rect(box_x, box_y, box_w, box_h)
    pygame.draw.rect(screen, (20, 30, 70), box, border_radius=12)
    pygame.draw.rect(screen, BOARD_HIGHLIGHT, box, 2, border_radius=12)

    mode_title = MENU_FONT.render("GAME MODE", True, WHITE)
    screen.blit(mode_title, (WIDTH // 2 - mode_title.get_width() // 2, box_y + 15))

    for i, (key, name, desc) in enumerate(modes):
        y = box_y + 75 + i * 65
        is_selected = selected_mode == i + 1
        color = GOLD if is_selected else WHITE
        bg_color = (50, 60, 100) if is_selected else (30, 40, 70)

        btn = pygame.Rect(box_x + 30, y, box_w - 60, 50)
        pygame.draw.rect(screen, bg_color, btn, border_radius=8)
        if is_selected:
            pygame.draw.rect(screen, GOLD, btn, 2, border_radius=8)

        key_circle = pygame.Surface((30, 30), pygame.SRCALPHA)
        pygame.draw.circle(key_circle, (*GOLD, 80) if is_selected else (*GREY, 60), (15, 15), 15)
        screen.blit(key_circle, (box_x + 45, y + 10))
        key_text = INFO_FONT.render(key, True, color)
        screen.blit(key_text, (box_x + 56, y + 14))

        name_text = SCORE_FONT.render(name, True, color)
        screen.blit(name_text, (box_x + 85, y + 5))

        desc_text = SMALL_FONT.render(desc, True, GREY if not is_selected else (200, 200, 200))
        screen.blit(desc_text, (box_x + 85, y + 30))

    diff_y = box_y + box_h + 20
    diff_box = pygame.Rect(box_x, diff_y, box_w, 140)
    pygame.draw.rect(screen, (20, 30, 70), diff_box, border_radius=12)
    pygame.draw.rect(screen, BOARD_HIGHLIGHT, diff_box, 2, border_radius=12)

    diff_title = MENU_FONT.render("AI DIFFICULTY", True, WHITE)
    screen.blit(diff_title, (WIDTH // 2 - diff_title.get_width() // 2, diff_y + 10))

    for i, (key, name, desc) in enumerate(diffs):
        y = diff_y + 55 + i * 28
        is_selected = selected_diff == i + 1
        color = GOLD if is_selected else WHITE

        diff_colors = [GREEN, YELLOW, RED]
        marker_color = diff_colors[i] if is_selected else GREY
        pygame.draw.circle(screen, marker_color, (box_x + 50, y + 8), 6)

        name_text = SMALL_FONT.render(name, True, color)
        screen.blit(name_text, (box_x + 65, y - 2))

    start_y = diff_y + 165
    pulse = abs(math.sin(time_val * 3)) * 0.3 + 0.7
    start_btn = pygame.Rect(box_x + 60, start_y, box_w - 120, 45)
    start_color = (int(30 * pulse + 20), int(180 * pulse), int(60 * pulse))
    pygame.draw.rect(screen, start_color, start_btn, border_radius=10)
    pygame.draw.rect(screen, WHITE, start_btn, 2, border_radius=10)

    start_text = MENU_FONT.render("START GAME", True, WHITE)
    screen.blit(start_text, (WIDTH // 2 - start_text.get_width() // 2, start_y + 4))

    hint = SMALL_FONT.render("Press ENTER or click to start", True, GREY)
    screen.blit(hint, (WIDTH // 2 - hint.get_width() // 2, start_y + 55))


def draw_game_over(piece, mode, particles, winner_name=None):
    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 160))
    screen.blit(overlay, (0, 0))

    time_val = pygame.time.get_ticks() * 0.001
    pulse = abs(math.sin(time_val * 2)) * 0.2 + 0.8

    box_w, box_h = 480, 240
    box_x = WIDTH // 2 - box_w // 2
    box_y = HEIGHT // 2 - box_h // 2

    glow_color = RED_LIGHT if piece == 1 else (YELLOW_LIGHT if piece == 2 else (200, 200, 200))
    glow_surf = pygame.Surface((box_w + 20, box_h + 20), pygame.SRCALPHA)
    pygame.draw.rect(glow_surf, (*glow_color, int(40 * pulse)),
                     (0, 0, box_w + 20, box_h + 20), border_radius=20)
    screen.blit(glow_surf, (box_x - 10, box_y - 10))

    pygame.draw.rect(screen, (25, 35, 80), (box_x, box_y, box_w, box_h), border_radius=15)
    pygame.draw.rect(screen, glow_color, (box_x, box_y, box_w, box_h), 3, border_radius=15)

    if piece == 1:
        name = "RED" if mode == 1 else "YOU"
        icon_color = RED
    elif piece == 2:
        name = "YELLOW" if mode == 1 else "AI"
        icon_color = YELLOW
    else:
        name = "DRAW"
        icon_color = GREY

    if name != "DRAW":
        for _ in range(30):
            px = random.randint(box_x, box_x + box_w)
            py = random.randint(box_y, box_y + box_h)
            particles.append(Particle(px, py, icon_color))

    if name == "DRAW":
        win_text = WIN_FONT.render("IT'S A DRAW!", True, SILVER)
        screen.blit(win_text, (WIDTH // 2 - win_text.get_width() // 2, box_y + 50))
    else:
        win_text = WIN_FONT.render(f"{name} WINS!", True, icon_color)
        screen.blit(win_text, (WIDTH // 2 - win_text.get_width() // 2, box_y + 40))

        trophy = WIN_FONT.render("*", True, GOLD)
        screen.blit(trophy, (box_x + 20, box_y + 40))
        screen.blit(trophy, (box_x + box_w - 50, box_y + 40))

    restart_text = SCORE_FONT.render("Press R to Restart", True, WHITE)
    menu_text = SCORE_FONT.render("Press M for Menu", True, WHITE)
    screen.blit(restart_text, (WIDTH // 2 - restart_text.get_width() // 2, box_y + 130))
    screen.blit(menu_text, (WIDTH // 2 - menu_text.get_width() // 2, box_y + 170))
